import serial
from serial.tools import list_ports
from PyQt5 import QtWidgets
# python -m serial.tools.list_ports
# from south import Ui_MainWindow
from south import Ui_MainWindow

for i in list_ports.comports():
	print(i[1])


def read_com(ser):
	while True:
		# print(type(ser.read()))
		# print(ser.read().decode().strip())
		print(str(str(ser.readline()).split(':')[1]).split('\\')[0])


def s_un():
	import sys
	app = QtWidgets.QApplication(sys.argv)
	main_window = QtWidgets.QMainWindow()
	ui = Ui_MainWindow()
	ui.setupUi(main_window)
	# ui.shit("shit")
	main_window.show()
	sys.exit(app.exec_())


def ser_conn(comm, baud):
	print("construct : ")
	uui = Ui_MainWindow()
	# uui.shit()
	uui.shit("11.111", "22.22", "33.33")
	s_un()
	try:
		ser = serial.Serial(comm, baud, timeout=1)
		print(ser.name)
		read_com(ser)
	except:
		print('except')
	finally:
		print('nal')
# def drop_c():
# 	ser.write(b'1')     # write a string for DROP
#


ser_conn('COM14', 115200)


# ser.close()
