# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'guages.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1754, 926)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-10, 20, 1811, 971))
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(270, 420, 181, 51))
        self.lineEdit.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setGeometry(QtCore.QRect(270, 520, 181, 51))
        self.lineEdit_4.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_5.setGeometry(QtCore.QRect(270, 630, 181, 51))
        self.lineEdit_5.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(700, 630, 181, 51))
        self.lineEdit_2.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(700, 520, 181, 51))
        self.lineEdit_3.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_6 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_6.setGeometry(QtCore.QRect(700, 420, 181, 51))
        self.lineEdit_6.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(980, 600, 231, 91))
        self.pushButton_2.setStyleSheet("QPushButton{\n"
"    border :2px solid rgb(255,255,255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(255,255,255);\n"
"    font-size:24px\n"
"}\n"
"QPushButton:hover{\n"
"    background-colour:rgb(198, 198, 198)\n"
"}")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(980, 490, 231, 81))
        self.pushButton_3.setStyleSheet("QPushButton{\n"
"    border :2px solid rgb(251,252,83);\n"
"    border-radius:20px;\n"
"    background-color: rgb(251,252,83);\n"
"     font-size:24px;\n"
"}\n"
"QPushButton:hover{\n"
"    background-colour:rgb(255, 255, 127)\n"
"}")
        self.pushButton_3.setObjectName("pushButton_3")
        self.lineEdit_7 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_7.setGeometry(QtCore.QRect(980, 410, 231, 51))
        self.lineEdit_7.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:20px;\n"
"    background-color: rgb(85, 255, 255);\n"
"}")
        self.lineEdit_7.setObjectName("lineEdit_7")
        self.lineEdit_8 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_8.setGeometry(QtCore.QRect(920, 60, 321, 301))
        self.lineEdit_8.setStyleSheet("QLineEdit{\n"
"    border :2px solid rgb(0, 255, 255);\n"
"    border-radius:10px;\n"
"    background-color: rgb(85, 255, 255);\n"
"    font-size:330px\n"
"}")
        self.lineEdit_8.setObjectName("lineEdit_8")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(50, 420, 151, 51))
        self.label_2.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(50, 520, 151, 51))
        self.label_3.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(50, 630, 151, 51))
        self.label_4.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(490, 420, 151, 51))
        self.label_5.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(490, 520, 151, 51))
        self.label_6.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(490, 630, 151, 51))
        self.label_7.setStyleSheet("\n"
"color: rgb(255, 255, 255);")
        self.label_7.setObjectName("label_7")
        self.graphicsView = PlotWidget(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(1320, 40, 401, 361))
        self.graphicsView.setObjectName("graphicsView")
        self.widget = AnalogGaugeWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(470, 60, 391, 301))
        self.widget.setObjectName("widget")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1754, 26))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\"><img src=\":/g1/----------.png\"/></p></body></html>"))
        self.pushButton_2.setText(_translate("MainWindow", "PADA"))
        self.pushButton_3.setText(_translate("MainWindow", "CALIBRATE"))
        self.lineEdit_8.setText(_translate("MainWindow", "1"))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">ROLL</span></p></body></html>"))
        self.label_3.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">PITCH</span></p></body></html>"))
        self.label_4.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">YAW</span></p></body></html>"))
        self.label_5.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">AIR SPEED</span></p></body></html>"))
        self.label_6.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">TIMER</span></p></body></html>"))
        self.label_7.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-size:18pt;\">ACCE.</span></p></body></html>"))
from AnalogGaugeWidget import AnalogGaugeWidget
from pyqtgraph import PlotWidget
import g1


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
