from machine import  Pin, ADC
import utime

POT_Value=ADC(26)
conversion_fac=3.3/(65536)

while True:
	print(POT_Value.read_u16() * conversion_fac)
	utime.sleep(0.1)